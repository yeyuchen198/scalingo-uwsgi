import{av as e,a,o as n,h as o}from"./index.63aad524.js";const r=a({name:"FrameBlank"});function t(s,c,p,m,_,f){return n(),o("div")}var i=e(r,[["render",t]]);export{i as default};
