import{dG as e}from"./index.63aad524.js";const s=t=>e.get({url:"/select/getDemoOptions",params:t}),i=t=>e.get({url:"/tree/getDemoOptions",params:t});export{s as o,i as t};
