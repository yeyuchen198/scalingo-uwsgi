var a="/assets/header.1b5fa5f8.jpg";export{a as h};
