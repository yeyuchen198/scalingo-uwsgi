import{v as s,co as a}from"./index.63aad524.js";var t=function(){var e=s(new Map),r=function(f){return function(n){e.value.set(f,n)}};return a(function(){e.value=new Map}),[r,e]},c=t;export{c as u};
