import{b as n}from"./_baseIteratee.2feb8f6d.js";import{cn as o}from"./index.63aad524.js";function m(e,t){return e&&e.length?o(e,n(t)):[]}export{m as u};
