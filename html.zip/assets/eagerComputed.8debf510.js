import{af as t,L as f}from"./index.63aad524.js";function o(a){var e=t();return f(function(){e.value=a()},{flush:"sync"}),e}export{o as e};
