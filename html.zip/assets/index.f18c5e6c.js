import{R as a,C as r}from"./Col.b6341743.js";import{U as o}from"./index.63aad524.js";var l=o(a),m=o(r);export{m as C,l as R};
