import{v as a,N as r,aL as t}from"./index.63aad524.js";var u=function(){var e=a(!1);return r(function(){e.value=t()}),e};export{u};
